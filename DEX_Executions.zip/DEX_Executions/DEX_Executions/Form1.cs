﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace DEX_Executions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void runCommand(String cmd)
        {
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/C " + cmd;
            process.StartInfo = startInfo;
            process.Start();
            process.WaitForExit();
        }


        public void runFile(String filename)
        {
            ProcessStartInfo cmdsi = new ProcessStartInfo("Repetitions.bat");
            //cmdsi.Arguments = "Repetitions.bat";
            Process cmd = Process.Start(cmdsi);
            cmd.WaitForExit();
        }

        public void runCmd(String command)
        {
            System.Diagnostics.Process.Start("CMD.exe", "/C " + command).WaitForExit();
        }

        public void oldScript()
        {
            string fileName = "Repetitions.bat";
            string fileContents = "@title DEX Executions\r\n@echo OFF\r\nset /p rep=<Repetitions.txt\r\nset /p ToscaClientPath=<source\\ToscaClientPath.txt\r\nset /p ResultXMLPath=<source\\ResultXMLPath.txt\r\nset /p InputXMLPath=<source\\InputXMLPath.txt\r\nset /p TCShellPath=<source\\TCShellPath.txt\r\nset /p WorkspacePath=<source\\WorkspacePath.txt\r\nset /p tcsFilePath=<source\\tcsFilePath.txt\r\nset /p ReportPath=<source\\ReportPath.txt\r\nset /p NodePath=<source\\NodePath.txt\r\n\r\nFOR /L %%i IN (1,1,%rep%) DO (\r\necho.\r\necho.\r\necho.\r\necho.\r\necho.\r\necho.\r\nFor /f \"tokens=2-4 delims=/ \" %%a in (\'date /t\') do (set mydate=%%c-%%a-%%b)\r\nFor /f \"tokens=1-2 delims=/:\" %%a in (\'time /t\') do (set mytime=%%a%%b)\r\necho        ITERATION %%i of %rep%\r\necho        ====================\r\necho.\r\necho.\r\necho.\r\necho        EXECUTING COMMAND:\r\necho        ==================\r\necho \"%ToscaClientPath%\" -m distributed -r \"%ResultXMLPath%\" -c \"%InputXMLPath%\" -l \"Robot\" -p \"Telstra\" -x \"False\" -e \"http://localhost:8888/DistributionServerService/ManagerService.svc\"\r\n@echo ON\r\n\"%ToscaClientPath%\" -m distributed -r \"%ResultXMLPath%\" -c \"%InputXMLPath%\" -l \"Robot\" -p \"Telstra\" -x \"False\" -e \"http://localhost:8888/DistributionServerService/ManagerService.svc\"\r\n@echo OFF\r\necho.\r\necho Execution finished!\r\necho.\r\necho.\r\necho.\r\necho.\r\necho.\r\necho.\r\necho        Creating Dynamic TCS file...\r\necho        ============================\r\n>\"DynamicReport.TCS\" echo(Updateall\r\n>>\"DynamicReport.TCS\" echo.\r\n>>\"DynamicReport.TCS\" echo(jumptonode \"%NodePath%\"\r\n>>\"DynamicReport.TCS\" echo.\r\n>>\"DynamicReport.TCS\" echo(task \"Print Report ... DetailedReports_V1\"\r\n>>\"DynamicReport.TCS\" echo(%ReportPath%_%mydate%_%mytime%.pdf\r\n>>\"DynamicReport.TCS\" echo.\r\n>>\"DynamicReport.TCS\" echo(save\r\n>>\"DynamicReport.TCS\" echo.\r\n>>\"DynamicReport.TCS\" echo(exit\r\necho.\r\necho TCS file created successfully!\r\necho.\r\necho.\r\necho.\r\necho.\r\necho        GENERATING REPORT\r\necho        =================\r\necho Command:\r\necho \"%TCShellPath%\" -workspace \"%WorkspacePath%\" -executionmode -login \"Robot\" \"Telstra\" \"%tcsFilePath%\"\r\n@echo ON\r\n\"%TCShellPath%\" -workspace \"%WorkspacePath%\" -executionmode -login \"Robot\" \"Telstra\" \"%tcsFilePath%\"\r\n@echo OFF\r\necho.\r\necho Report generation finished.\r\n)\r\necho.\r\necho.\r\necho.\r\necho.\r\necho.\r\necho Finished batch execution.\r\n";
            File.WriteAllText(fileName, fileContents);
            runCommand("attrib +H +S Repetitions.bat");
            runFile("Repetitions.bat");
            runCommand("attrib -H -S Repetitions.bat");
            runCommand("del Repetitions.bat");
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //new Thread(delegate () {
            //script();
            //}).Start();
            script();
            this.Close();
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            
        }

        public string getWebText()
        {
            var webRequest = System.Net.WebRequest.Create(@"https://raw.githubusercontent.com/swarnavn/Telstra/master/Licence.txt");
            string strContent = "";

            using (var response = webRequest.GetResponse())
            using (var content = response.GetResponseStream())
            using (var reader = new StreamReader(content))
            {
                strContent = reader.ReadToEnd();
            }

            return strContent;
        }

        public void prechecks()
        {
            try
            {
                //Check license from local machine
                if (File.ReadAllText(@"\\SWARNAVN01\License\License.txt").Contains(System.Security.Principal.WindowsIdentity.GetCurrent().Name.Substring(6).ToLower()))
                {
                    ;
                }

                //Check license from web if not available on local machine
                else if (getWebText().Contains(System.Security.Principal.WindowsIdentity.GetCurrent().Name.Substring(6).ToLower()))
                {
                    ;
                }
                else
                {
                    MessageBox.Show("Unauthorized access.", "FATAL ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    System.Windows.Forms.Application.Exit();
                }


            }
            catch (Exception e1)
            {
                //MessageBox.Show("Cannot connect Amdocs machine for access.", "WARNING!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                try
                {
                    if (getWebText().Contains(System.Security.Principal.WindowsIdentity.GetCurrent().Name.Substring(6).ToLower()))
                    {
                        ;
                    }
                    else
                    {
                        MessageBox.Show("Unauthorized access.", "FATAL ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        System.Windows.Forms.Application.Exit();
                    }
                }
                catch (Exception e2)
                {
                    MessageBox.Show("Cannot access internet. Access information cannot be fetched.", "FATAL ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    System.Windows.Forms.Application.Exit();
                }
            }
        }

        public void script()
        {
            prechecks();
            String dtm = DateTime.Now.ToString("yyyy-MM-ddTHH-mm");
            String rep = File.ReadAllText(@"Repetitions.txt");
            String ToscaClientPath = File.ReadAllText(@"source\ToscaClientPath.txt");
            String ResultXMLPath = File.ReadAllText(@"source\ResultXMLPath.txt");
            String InputXMLPath = File.ReadAllText(@"source\InputXMLPath.txt");
            String TCShellPath = File.ReadAllText(@"source\TCShellPath.txt");
            String WorkspacePath = File.ReadAllText(@"source\WorkspacePath.txt");
            String tcsFilePath = File.ReadAllText(@"source\tcsFilePath.txt");
            String ReportPath = File.ReadAllText(@"source\ReportPath.txt");
            String NodePath = File.ReadAllText(@"source\NodePath.txt");
            String ReportType = File.ReadAllText(@"source\ReportType.txt", Encoding.ASCII);
            String execCmd = "";
            String reportCmd = "";

            for (int i = 0; i < Int32.Parse(rep); i++)
            {
                String tcsFileContents = "Updateall\r\n\r\njumptonode \"" + NodePath + "\"\r\n\r\ntask \"Print Report ... " + ReportType + "\"\r\n" + ReportPath + "_" + dtm + ".pdf\r\n\r\nsave\r\n\r\nexit\r\n";
                File.WriteAllText("DynamicReport.tcs", tcsFileContents);
                //lblStatus.Text = "Executing Flow: Iteration " + (i + 1) + " of " + Int32.Parse(rep);
                execCmd = "\"" + ToscaClientPath + "\" -m distributed -r \"" + ResultXMLPath + "\" -c \"" + InputXMLPath + "\" -l \"Robot\" -p \"Telstra\" -x \"False\" -e \"http://localhost:8888/DistributionServerService/ManagerService.svc\"";
                reportCmd = "\"" + TCShellPath + "\" -workspace \"" + WorkspacePath + "\" -executionmode -login \"Robot\" \"Telstra\" \"" + tcsFilePath + "\"";
                File.WriteAllText("Command.bat", execCmd+"\r\n"+reportCmd);
                runCmd("Command.bat");
            }
        }

    }
}
