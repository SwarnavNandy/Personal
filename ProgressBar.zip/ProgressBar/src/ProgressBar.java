import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class ProgressBar {

	private JFrame frame;
	JProgressBar pb;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProgressBar obj = new ProgressBar();
		obj.ProgBar(10, 10, "ProgressBar", "Label");
	}

	public void ProgBar(int Steps, int limit, String title, String lbl) {
		
		frame = new JFrame(title);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		frame.getContentPane().add(lblNewLabel);
		
		pb = new JProgressBar();
		pb.setBounds(10, 93, 264, 26);
		pb.setMinimum(0);
        pb.setMaximum(Steps);
        pb.setStringPainted(true);
        frame.getContentPane().add(pb);
        
        JLabel lblNewLabel_1 = new JLabel(lbl);
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblNewLabel_1.setBounds(27, 33, 224, 49);
        frame.getContentPane().add(lblNewLabel_1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setVisible(true);
        
        // update progressbar
        for (int i = 0; i <= limit; i++) {
            int currentValue = i;
            try {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        pb.setValue(currentValue);
                    }
                });
                java.lang.Thread.sleep(50);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
        System.exit(1);
	}
}
