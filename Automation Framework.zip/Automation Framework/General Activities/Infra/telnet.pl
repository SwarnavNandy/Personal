use strict;
use Net::TelnetNew;
use File::Path;
#use warnings;

my $Server=$ARGV[0];
my $username=$ARGV[1];
my $password=$ARGV[2];
my $sCommand=$ARGV[3] . ";echo Auto_Done";
my $timeoutforsync=$ARGV[4];
my $expectedprompt=$ARGV[5];
my $FILE_NAME = $ARGV[6];

if($expectedprompt eq "")
{
	$expectedprompt="Auto_Done";		
}


my %enterarr;

my $t = new Net::TelnetNew (Timeout => 30,Port=>23,Host=>$Server,Errmode=>'return');

my %cmdArr=("Name"=>$username, "Password"=>$password, "Prompt"=>"/>/", "Timeout"=>$timeoutforsync, Errmode=>'return');
my $ok=$t->login(%cmdArr);
my $msg = $t->errmsg;
if($msg ne "")
{
	   open (my $fh,">",$FILE_NAME) or die "could not open '$FILE_NAME'\n";
	   print $fh ("Message returned from UNIX: \n");
           print $fh ("$msg");
	   print $fh ("ERROR\n");
	   close($fh);
	   exit;
}

if($sCommand eq "")
{
	   open (my $fh,">",$FILE_NAME) or die "could not open '$FILE_NAME'\n";
	   print $fh ("Message returned from UNIX: \n");
           print $fh ($ok);

	   close($fh);
	   exit;
}

if($expectedprompt ne "")
{
	%enterarr=("String"=>"$sCommand", "Timeout"=>$timeoutforsync, Prompt=>"/$expectedprompt/", Errmode=>'return');
}
else
{
	%enterarr=("String"=>"$sCommand", "Timeout"=>$timeoutforsync, Errmode=>'return');
}

my @arry=$t->cmd(%enterarr);

$msg = $t->errmsg;

if($msg eq "")
{
	open (my $fh,">",$FILE_NAME) or die "could not open '$FILE_NAME'\n";
	print $fh ("Message returned from UNIX: \n");
	print $fh (@arry);
	print $fh ($expectedprompt);
	close($fh);
}
else
{
	open (my $fh,">",$FILE_NAME) or die "could not open '$FILE_NAME'\n";
	print $fh ("Message returned from UNIX: \n");
	print $fh ("$msg");
	print $fh ("ERROR\n");
	#print $fh ("Data on Telnet: \n");
	#print $fh (@arry);
	close($fh);
}

$t->close();
